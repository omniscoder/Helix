"""PAM definitions, validators, and helpers."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, Sequence

from helix import bioinformatics

_IUPAC: Mapping[str, Sequence[str]] = {
    "A": ("A",),
    "C": ("C",),
    "G": ("G",),
    "T": ("T", "U"),
    "U": ("T", "U"),
    "R": ("A", "G"),
    "Y": ("C", "T", "U"),
    "S": ("G", "C"),
    "W": ("A", "T", "U"),
    "K": ("G", "T", "U"),
    "M": ("A", "C"),
    "B": ("C", "G", "T", "U"),
    "D": ("A", "G", "T", "U"),
    "H": ("A", "C", "T", "U"),
    "V": ("A", "C", "G"),
    "N": ("A", "C", "G", "T", "U"),
}


@dataclass(frozen=True)
class PAM:
    """Container describing a PAM pattern."""

    name: str
    pattern: str
    orientation: str = "3prime"  # guide-3' adjacency (SpCas9 default)
    notes: str | None = None

    def as_dict(self) -> Dict[str, str]:
        return {"name": self.name, "pattern": self.pattern, "orientation": self.orientation, "notes": self.notes}


_DEFAULT_PAMS: Dict[str, PAM] = {
    "SpCas9-NGG": PAM(name="SpCas9-NGG", pattern="NGG", orientation="3prime", notes="canonical SpCas9"),
    "SaCas9-NNGRRT": PAM(name="SaCas9-NNGRRT", pattern="NNGRRT", orientation="3prime"),
    "SpRY-NNN": PAM(name="SpRY-NNN", pattern="NNN", orientation="3prime", notes="near-PAMless"),
}


def list_pams() -> Sequence[str]:
    """Return the registered PAM names."""

    return tuple(sorted(_DEFAULT_PAMS))


def get_pam(name: str) -> Dict[str, str]:
    """Return a PAM definition by name."""

    try:
        pam = _DEFAULT_PAMS[name]
    except KeyError as exc:  # pragma: no cover - defensive
        raise ValueError(f"Unknown PAM '{name}'. Known PAMs: {', '.join(list_pams())}.") from exc
    return pam.as_dict()


def register_pam(pam: PAM) -> None:
    """Register a PAM at runtime (useful for notebooks/tests)."""

    _DEFAULT_PAMS[pam.name] = pam


def match_pam(seq: str, pam: Mapping[str, str] | PAM, pos: int = 0) -> bool:
    """Return True if `seq[pos:pos+len(pattern)]` satisfies the PAM rule."""

    if isinstance(pam, PAM):
        pattern = pam.pattern
    else:
        pattern = str(pam.get("pattern", ""))
    if not pattern:
        return False
    region = seq[pos : pos + len(pattern)].upper()
    if len(region) != len(pattern):
        return False
    for base, symbol in zip(region, pattern.upper()):
        allowed = _IUPAC.get(symbol)
        if not allowed or base.upper() not in allowed:
            return False
    return True


_IUPAC_COMPLEMENT = {
    "A": "T",
    "C": "G",
    "G": "C",
    "T": "A",
    "U": "A",
    "R": "Y",
    "Y": "R",
    "S": "S",
    "W": "W",
    "K": "M",
    "M": "K",
    "B": "V",
    "D": "H",
    "H": "D",
    "V": "B",
    "N": "N",
}


def reverse_complement_pattern(pattern: str) -> str:
    """Return the reverse complement for an IUPAC pattern string."""

    letters = []
    for char in reversed(pattern.upper()):
        letters.append(_IUPAC_COMPLEMENT.get(char, "N"))
    return "".join(letters)


PAM_MOTIFS: Dict[str, str] = {
    "SpCas9_NGG": "NGG",
    "SpG_NGN": "NGN",
    "SpRY_NNN": "NNN",
    "SaCas9_NNGRRT": "NNGRRT",
    "Cas12a_TTTN": "TTTN",
}


def _match_motif(seq: str, motif: str) -> bool:
    """Return True when `seq` satisfies the provided motif (supports N wildcards)."""

    seq = seq.upper()
    motif = motif.upper()
    if len(seq) != len(motif):
        return False
    for base, symbol in zip(seq, motif):
        if symbol == "N":
            continue
        if base != symbol:
            return False
    return True


def build_crispr_pam_mask(
    site_seq: str,
    guide: Mapping[str, object] | None,
    pam_profile: str,
    pam_softness: float,
) -> List[float]:
    """
    Construct a position-wise PAM weight mask.

    Positions that match the PAM motif receive weight 1.0.
    Non-matching positions receive `pam_softness` (clamped to [0, 1]).
    """

    normalized = bioinformatics.normalize_sequence(site_seq)
    length = len(normalized)
    if length == 0:
        return []

    key = (pam_profile or "SpCas9_NGG").strip() or "SpCas9_NGG"
    motif = PAM_MOTIFS.get(key) or PAM_MOTIFS.get(key.replace("-", "_"))
    if motif is None:
        raise ValueError(f"Unknown PAM profile: {pam_profile}")

    softness = max(0.0, min(1.0, float(pam_softness)))
    mask = [softness] * length
    motif = motif.upper()
    motif_len = len(motif)
    upper_seq = normalized.upper()

    for idx in range(length - motif_len + 1):
        window = upper_seq[idx : idx + motif_len]
        if _match_motif(window, motif):
            for offset in range(motif_len):
                mask[idx + offset] = 1.0

    _ = guide
    return mask


def build_prime_pam_mask(
    site_seq: str,
    peg: Mapping[str, object] | None,
    pam_profile: str,
    pam_softness: float,
) -> List[float]:
    """Alias of build_crispr_pam_mask for semantic clarity."""

    return build_crispr_pam_mask(site_seq, peg, pam_profile, pam_softness)
